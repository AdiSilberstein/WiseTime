import flet as ft
from datetime import datetime, timedelta
import time

# Global variables
notes = []
notes_widgets = []  # Widgets to hold note texts dynamically
countdown_active = False

def main(page: ft.Page):
    page.title = "TimeWise"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.auto_scroll = True
    page.scroll = ft.ScrollMode.HIDDEN
    page.appbar = ft.AppBar(
        title=ft.Text("TimeWise", weight=ft.FontWeight.BOLD, color=ft.colors.BLACK87),
        bgcolor=ft.colors.BLUE,
        center_title=True,
        color=ft.colors.WHITE,
    )
    page.add(ft.Text("Focus on one task at time!", weight=ft.FontWeight.BOLD, color=ft.colors.BLACK87))

    def button_clicked(e):
        note_text = AddTask.value.strip()
        if note_text:
            notes.append(note_text)
            update_notes_display()
            AddTask.value = ""  # Clear text field after adding note
            page.update()

    def update_notes_display():
        # Clear existing note widaets before updating
        for widget in notes_widgets:
            page.remove(widget)
        notes_widgets.clear()

        # Create new note widgets
        for i, note in enumerate(notes):
            note_widget = ft.Text(f"Note {i + 1}: {note}")
            notes_widgets.append(note_widget)
            page.add(note_widget)

    def finish_clicked(e):
        global countdown_active
        countdown_active = False
        page.add(ft.Text("Note finished!"))        

    AddTask = ft.TextField(label="Add your task")
    submit = ft.ElevatedButton(text="Submit", on_click=button_clicked)
    page.add(AddTask)

    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    selected_time = None

    def handle_change(e):
        nonlocal selected_time
        selected_time = time_picker.value
        current_time = datetime.now()
        # Combine selected_time with today's date to form a datetime object
        selected_datetime = datetime.combine(datetime.today(), selected_time)
        # Calculate time difference
        time_diff = selected_datetime - current_time
        if time_diff.total_seconds() > 0:
            start_countdown(time_diff)
        else:
            page.add(ft.Text("Selected time is in the past!"))

    def start_countdown(duration):
        global countdown_active
        countdown_active = True
        timer_text = ft.Text()
        page.add(timer_text)

        while duration.total_seconds() > 0 and countdown_active:
            timer_text.value = f"Time left: {duration.seconds // 3600} hours {duration.seconds % 3600 // 60} minutes {duration.seconds % 60} seconds"
            page.update()
            time.sleep(1)
            duration -= timedelta(seconds=1)

        if countdown_active:
            timer_text.value = "Time's up! Try your best next time!"
            page.update()
        else:
            timer_text.value = "Well done! keep going!"
            page.update()

    def handle_dismissal(e):
        page.add(ft.Text(f"TimePicker dismissed: {time_picker.value}"))

    def handle_entry_mode_change(e):
        page.add(ft.Text(f"TimePicker Entry mode changed to {e.entry_mode}"))

    time_picker = ft.TimePicker(
        confirm_text="Confirm",
        error_invalid_text="Time out of range",
        help_text="Pick your time slot",
        on_change=handle_change,
        on_dismiss=handle_dismissal,
        on_entry_mode_change=handle_entry_mode_change,
    )

    page.add(
        ft.ElevatedButton(
            "Pick time",
            icon=ft.icons.TIMER,
            on_click=lambda _: page.open(time_picker),
        )
    )

    finish_button = ft.ElevatedButton(
        "Finish",
        on_click=finish_clicked,
    )
    page.add(submit)
    page.add(finish_button)

    # Update notes display initially
    update_notes_display()

    # You can also optionally start the countdown if a time is already selected
    if selected_time is not None:
        current_time = datetime.now()
        selected_datetime = datetime.combine(datetime.today(), selected_time)
        time_diff = selected_datetime - current_time
        if time_diff.total_seconds() > 0:
            start_countdown(time_diff)

ft.app(target=main)
